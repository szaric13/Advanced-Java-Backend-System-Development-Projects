package rs.raf;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Main {

    private static final int PORT = 9001;
    private static final String SERVER_ADDRESS = "127.0.0.1";

    public static void main(String[] args) {
        new Main().startClient();
    }

    public void startClient() {
        try (Socket socket = new Socket(SERVER_ADDRESS, PORT);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {

            Scanner scanner = new Scanner(System.in);

            // Čitanje dobrodošlice i unosa korisničkog imena
            String response = in.readLine();
            System.out.println(response);

            // Unos korisničkog imena
            String username = scanner.nextLine();
            out.println(username);

            // Kreiranje i pokretanje novog threada za čitanje poruka
            Thread clientThread = new Thread(new ClientThread(in));
            clientThread.start();

            // Slanje poruka
            while (true) {
                String message = scanner.nextLine();
                out.println(message);
                if (message.equalsIgnoreCase("exit")) {
                    break;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
