package rs.raf;

import java.io.*;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class ServerThread extends Thread {
    private Socket socket;
    private ConcurrentHashMap<String, ClientHandler> clientMap;
    private PrintWriter out;
    private BufferedReader in;
    private String username;
    private static final int MESSAGE_HISTORY_LIMIT = 100;
    private static List<String> messageHistory = new ArrayList<>(); // Čuvanje istorije poruka
    private static final Set<String> censoredWords = new HashSet<>(Arrays.asList("badword1", "badword2")); // Cenzurisane reči

    public ServerThread(Socket socket, ConcurrentHashMap<String, ClientHandler> clientMap) {
        this.socket = socket;
        this.clientMap = clientMap;
    }

    @Override
    public void run() {
        try {
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            // Identifikacija korisnika
            out.println("Unesite korisničko ime:");
            String clientUsername = in.readLine();

            synchronized (clientMap) {
                while (clientMap.containsKey(clientUsername)) {
                    out.println("Korisničko ime je zauzeto, pokušajte ponovo:");
                    clientUsername = in.readLine();
                }

                clientMap.put(clientUsername, new ClientHandler(clientUsername, out));
            }

            // Početna poruka dobrodošlice
            out.println("Dobrodošli, " + clientUsername + "!");
            broadcast(clientUsername + " se pridružio chatu.");

            // Prikazivanje istorije poruka
            synchronized (messageHistory) {
                for (String msg : messageHistory) {
                    out.println(msg);
                }
            }

            // Slušanje poruka od klijenta
            String message;
            while ((message = in.readLine()) != null) {
                if (message.equalsIgnoreCase("exit")) {
                    break;
                }
                // Cenzuriramo poruku pre nego što je prosledimo drugima
                String censoredMessage = censorMessage(message);
                broadcast(clientUsername + ": " + censoredMessage);
                storeMessage(clientUsername, censoredMessage); // Čuvanje poruke
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (username != null) {
                    synchronized (clientMap) {
                        clientMap.remove(username);
                    }
                    broadcast(username + " je napustio chat.");
                }

                if (in != null) in.close();
                if (out != null) out.close();
                if (socket != null) socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void broadcast(String message) {
        synchronized (clientMap) {
            for (ClientHandler client : clientMap.values()) {
                client.getOut().println(message);
            }
        }
    }

    private void storeMessage(String username, String message) {
        // Čuvanje poruke sa cenzurom
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        String fullMessage = timestamp + " - " + username + ": " + message;

        synchronized (messageHistory) {
            if (messageHistory.size() >= MESSAGE_HISTORY_LIMIT) {
                messageHistory.remove(0); // Uklanjanje najstarije poruke
            }
            messageHistory.add(fullMessage); // Dodavanje nove poruke
        }
    }

    // Metoda za cenzuriranje poruka
    private String censorMessage(String message) {
        // Iteriramo kroz sve cenzurisane reči
        for (String word : censoredWords) {
            // Proveravamo da li reč postoji u poruci
            if (message.toLowerCase().contains(word.toLowerCase())) {
                // Zamenjujemo svako pojavljivanje cenzurisanih reči
                String pattern = "(?i)\\b" + word + "\\b"; // (?i) omogućava neosetljivost na velika i mala slova
                message = message.replaceAll(pattern, replaceWithAsterisks(word));
            }
        }
        return message;
    }

    private String replaceWithAsterisks(String word) {
        if (word.length() <= 2) {
            return word; // Ako je reč vrlo kratka (npr. "aa"), ne cenzuriši
        }
        // Zamenjujemo sve karaktere osim prvog i poslednjeg sa "*"
        StringBuilder censoredWord = new StringBuilder();
        censoredWord.append(word.charAt(0)); // Prvo slovo
        for (int i = 1; i < word.length() - 1; i++) {
            censoredWord.append('*'); // Zvezda umesto karaktera
        }
        censoredWord.append(word.charAt(word.length() - 1)); // Poslednje slovo
        return censoredWord.toString();
    }


    public PrintWriter getOut() {
        return out;
    }
}
