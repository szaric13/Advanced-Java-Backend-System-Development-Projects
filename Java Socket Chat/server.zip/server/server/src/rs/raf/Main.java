package rs.raf;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ConcurrentHashMap;

public class Main {

    public static final int PORT = 9001;

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server je pokrenut i čeka konekcije...");

            // Kreiranje mape koja će držati klijente (username -> output stream)
            ConcurrentHashMap<String, ClientHandler> clientMap = new ConcurrentHashMap<>();

            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("Klijent se povezao.");

                // Kreiranje novog threada za svakog klijenta
                new ServerThread(socket, clientMap).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
