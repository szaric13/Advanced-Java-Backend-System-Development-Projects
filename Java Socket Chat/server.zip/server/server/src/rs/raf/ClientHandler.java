package rs.raf;

import java.io.PrintWriter;

public class ClientHandler {
    private String username;
    private PrintWriter out;

    public ClientHandler(String username, PrintWriter out) {
        this.username = username;
        this.out = out;
    }

    public String getUsername() {
        return username;
    }

    public PrintWriter getOut() {
        return out;
    }
}